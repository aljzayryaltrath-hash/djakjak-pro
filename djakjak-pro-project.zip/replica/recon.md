# Recon: Remini (Android) -> Djakjak Pro

Sources (public only): Google Play listing https://play.google.com/store/apps/details?id=com.bigwinepot.nwdn.international
No account was used, nothing was decompiled, no private APIs were looked at.

## Scope
- Platform: Android (APK, sideloaded)
- Slice: the core loop only. Pick a photo -> enhance -> compare before/after -> save/share.
- Audience: the user and Algerian users. Free, no ads, no subscription, no account.

## Core loop (from the store listing)
Turn an old / blurry / low-resolution photo into a sharper, higher-resolution one with one tap.
Listing promises: unblur, restore old or scratched photos, sharpen out-of-focus pictures,
add pixels to low-quality photos, improve faces.

## Screens
| ID | screen | purpose | states |
| --- | --- | --- | --- |
| S01 | Home | pick a photo from gallery or take one, short pitch | empty |
| S02 | Processing | progress while the model runs | loading, cancel, error |
| S03 | Result | before/after slider, save, share, enhance again | done, error, large image |
| S04 | About | name, licences (model attribution), privacy note | static |

## Flows
F01 Enhance a photo: S01 -> (pick) -> S02 -> S03 -> save or share. Happy path: 3 taps (pick, wait, save).

## Inferred data model
None needed. Everything stays on the phone: no accounts, no cloud, no history table.
(Original: accounts, subscriptions, cloud processing, ads. All deliberately dropped.)

## Hard parts
1. Running a super-resolution network on a phone (memory and speed): solved with tiling.
2. Large photos: cap the working size, tile with overlap so no seams show.
3. Face quality: a dedicated face-restoration model is too heavy for an APK. Deferred.

## Cannot be cloned (skip)
- Remini's own trained models and server-side processing (proprietary).
- AI avatars / generative "AI Photos" (needs large generative models + servers).
- Subscriptions, ads, accounts (removed on purpose).

## Size
M for the app, plus one external step: building the APK needs the Android SDK, which is
not reachable from the authoring environment, so the APK is built by GitHub Actions.
