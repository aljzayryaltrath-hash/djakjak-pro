import { enhance, loadEngine, getBackend } from './engine.js';

const $ = (id) => document.getElementById(id);
const Cap = window.Capacitor;
const isNative = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());

const screens = { home: $('screen-home'), busy: $('screen-busy'), result: $('screen-result') };
let cancelled = false;
let busy = false;
let resultBlob = null;
let urls = [];

function show(name) {
  for (const [k, el] of Object.entries(screens)) el.classList.toggle('active', k === name);
  window.scrollTo(0, 0);
}

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 3200);
}

function track(url) { urls.push(url); return url; }
function releaseUrls() { urls.forEach((u) => URL.revokeObjectURL(u)); urls = []; }

function fmtTime(ms) {
  const s = Math.max(1, Math.round(ms / 1000));
  if (s < 60) return `${s} ثانية`;
  const m = Math.floor(s / 60), r = s % 60;
  return r ? `${m} دقيقة و${r} ثانية` : `${m} دقيقة`;
}

async function decode(blob) {
  try {
    return await createImageBitmap(blob, { imageOrientation: 'from-image' });
  } catch (e) {
    return await createImageBitmap(blob);
  }
}

async function start(blob) {
  if (busy) return;
  busy = true; cancelled = false;
  releaseUrls();
  const quality = Number(document.querySelector('input[name="q"]:checked').value);

  const beforeUrl = track(URL.createObjectURL(blob));
  $('busy-preview').src = beforeUrl;
  $('bar-fill').style.width = '0%';
  $('busy-title').textContent = 'جاري تحسين الصورة…';
  $('busy-detail').textContent = 'تجهيز المحرك…';
  $('btn-cancel').disabled = false;
  show('busy');

  try {
    const bitmap = await decode(blob);
    await loadEngine();
    const t0 = performance.now();
    const res = await enhance(bitmap, quality, {
      shouldCancel: () => cancelled,
      onProgress: ({ done, total, avgMs }) => {
        $('bar-fill').style.width = `${Math.round((done / total) * 100)}%`;
        const left = (total - done) * avgMs;
        $('busy-detail').textContent =
          `${Math.round((done / total) * 100)}% · الجزء ${done} من ${total}` + (done < total ? ` · المتبقي تقريبا ${fmtTime(left)}` : '');
      },
    });
    bitmap.close && bitmap.close();

    resultBlob = res.blob;
    const afterUrl = track(URL.createObjectURL(res.blob));
    const before = $('img-before'), after = $('img-after');
    before.src = beforeUrl;
    after.src = afterUrl;
    $('slider').value = 50; setSplit(50);
    $('result-info').textContent =
      `${res.width}×${res.height} بكسل · استغرقت ${fmtTime(performance.now() - t0)}`;
    show('result');
  } catch (err) {
    if (String(err.message) === 'cancelled') {
      toast('تم إلغاء العملية');
    } else {
      console.error(err);
      toast('حدث خطأ أثناء المعالجة. جرّب مستوى أقل أو صورة أخرى.');
    }
    show('home');
  } finally {
    busy = false;
  }
}

function setSplit(v) {
  $('img-after').style.clipPath = `inset(0 0 0 ${v}%)`;
  $('divider').style.left = `${v}%`;
}

async function blobToBase64(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < buf.length; i += chunk) bin += String.fromCharCode.apply(null, buf.subarray(i, i + chunk));
  return btoa(bin);
}

async function saveOrShare() {
  if (!resultBlob) return;
  const name = `djakjak-pro-${Date.now()}.jpg`;
  try {
    if (isNative) {
      const file = await Cap.Plugins.Filesystem.writeFile({
        path: name, data: await blobToBase64(resultBlob), directory: 'CACHE',
      });
      await Cap.Plugins.Share.share({
        title: 'Djakjak Pro', dialogTitle: 'احفظ الصورة أو شاركها', files: [file.uri],
      });
    } else {
      const a = document.createElement('a');
      a.href = track(URL.createObjectURL(resultBlob));
      a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      toast('تم تنزيل الصورة');
    }
  } catch (err) {
    if (!/cancel/i.test(String(err && err.message))) {
      console.error(err);
      toast('تعذر الحفظ. حاول مرة أخرى.');
    }
  }
}

async function fromCamera() {
  if (isNative && Cap.Plugins.Camera) {
    try {
      const p = await Cap.Plugins.Camera.getPhoto({ quality: 100, resultType: 'uri', source: 'CAMERA', correctOrientation: true });
      const blob = await (await fetch(p.webPath)).blob();
      return start(blob);
    } catch (e) {
      if (!/cancel/i.test(String(e && e.message))) toast('تعذر فتح الكاميرا');
      return;
    }
  }
  $('file-camera').click();
}

// events
$('btn-gallery').addEventListener('click', () => $('file-input').click());
$('btn-camera').addEventListener('click', fromCamera);
for (const id of ['file-input', 'file-camera']) {
  $(id).addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (f) start(f);
  });
}
$('btn-cancel').addEventListener('click', () => {
  cancelled = true;
  $('btn-cancel').disabled = true;
  $('busy-title').textContent = 'جاري الإلغاء…';
});
$('btn-new').addEventListener('click', () => { resultBlob = null; releaseUrls(); show('home'); });
$('btn-save').addEventListener('click', saveOrShare);
$('slider').addEventListener('input', (e) => setSplit(e.target.value));

// drag on the picture itself
const cmp = $('compare');
let dragging = false;
const moveTo = (clientX) => {
  const r = cmp.getBoundingClientRect();
  const v = Math.min(100, Math.max(0, ((clientX - r.left) / r.width) * 100));
  $('slider').value = v; setSplit(v);
};
cmp.addEventListener('pointerdown', (e) => { dragging = true; cmp.setPointerCapture(e.pointerId); moveTo(e.clientX); });
cmp.addEventListener('pointermove', (e) => { if (dragging) moveTo(e.clientX); });
cmp.addEventListener('pointerup', () => { dragging = false; });
cmp.addEventListener('pointercancel', () => { dragging = false; });

// about
$('btn-about').addEventListener('click', async () => {
  const d = $('about');
  try {
    if (!$('notice').dataset.loaded) {
      $('notice').textContent = await (await fetch('NOTICE.txt')).text();
      $('notice').dataset.loaded = '1';
    }
  } catch (e) { $('notice').textContent = 'Real-ESRGAN (BSD-3-Clause), ONNX Runtime (MIT), Capacitor (MIT).'; }
  d.showModal();
});

// small hook for automated tests
window.__djakjak = { start, getBackend };
