// Djakjak Pro - on-device enhancement engine.
// Runs Real-ESRGAN "realesr-general-x4v3" (BSD-3-Clause) through ONNX Runtime Web.
// The photo never leaves the phone.

const TILE = 128;            // fixed network input size
const PAD = 10;              // overlap on every side, discarded after inference
const CORE = TILE - 2 * PAD; // useful pixels per tile
const SCALE = 4;
const MODEL_URL = './model/realesr-general-x4v3-t128.onnx';

let session = null;
let backend = '';

export function getBackend() { return backend; }

function reflect(i, n) {
  if (n === 1) return 0;
  while (i < 0 || i >= n) {
    if (i < 0) i = -i;
    if (i >= n) i = 2 * n - 2 - i;
  }
  return i;
}

function testTile() {
  // smooth colour gradient with a bit of texture, used for self-checks
  const t = new Float32Array(3 * TILE * TILE);
  const plane = TILE * TILE;
  for (let y = 0; y < TILE; y++) {
    for (let x = 0; x < TILE; x++) {
      const o = y * TILE + x;
      const checker = ((x >> 3) + (y >> 3)) & 1 ? 0.08 : 0;
      t[o] = x / TILE;
      t[plane + o] = y / TILE;
      t[2 * plane + o] = 0.3 + checker;
    }
  }
  return t;
}

function runTile(sess, data) {
  // pass a copy: with the worker-proxied WASM path the buffer is transferred and becomes unusable
  return sess.run({ input: new ort.Tensor('float32', data.slice(), [1, 3, TILE, TILE]) });
}

function finiteAndSpread(arr) {
  let min = Infinity, max = -Infinity;
  for (let i = 0; i < arr.length; i += 331) {
    const v = arr[i];
    if (!Number.isFinite(v)) return false;
    if (v < min) min = v;
    if (v > max) max = v;
  }
  return max - min > 1e-4;
}

async function create(ep) {
  return ort.InferenceSession.create(MODEL_URL, {
    executionProviders: [ep],
    graphOptimizationLevel: 'all',
  });
}

function maxAbsDiff(a, b) {
  let m = 0;
  for (let i = 0; i < a.length; i += 211) {
    const d = Math.abs(a[i] - b[i]);
    if (d > m) m = d;
  }
  return m;
}

/** Prepare the model. Tries the GPU path first, falls back to plain WASM. */
export async function loadEngine() {
  if (session) return backend;

  ort.env.wasm.wasmPaths = new URL('./ort/', location.href).href;
  ort.env.wasm.numThreads = 1; // the Android WebView is not cross-origin isolated
  ort.env.wasm.proxy = true;   // run WASM inference in a worker so the UI never freezes
  ort.env.logLevel = 'error';

  let remembered = null;
  try { remembered = localStorage.getItem('djakjak.backend'); } catch (e) { /* ignore */ }

  const order = remembered === 'wasm' ? ['wasm'] : ['webgl', 'wasm'];
  for (const ep of order) {
    try {
      const s = await create(ep);
      const probe = testTile();
      const r = await runTile(s, probe);
      const out = r.output.data;
      if (!finiteAndSpread(out)) throw new Error('empty output');

      if (ep === 'webgl' && remembered === null) {
        // first run only: check the GPU result against the CPU one, then keep whichever is faster
        const ref = await create('wasm');
        const rr = await runTile(ref, probe);
        const diff = maxAbsDiff(out, rr.output.data);
        if (diff > 0.05) throw new Error('webgl output differs: ' + diff);
        let t = performance.now();
        await runTile(s, probe);
        const gpuMs = performance.now() - t;
        t = performance.now();
        await runTile(ref, probe);
        const cpuMs = performance.now() - t;
        const useGpu = gpuMs < cpuMs * 0.9;
        session = useGpu ? s : ref;
        backend = useGpu ? 'webgl' : 'wasm';
        try { localStorage.setItem('djakjak.backend', backend); } catch (e) { /* ignore */ }
        return backend;
      }
      session = s; backend = ep;
      if (ep === 'wasm') { try { localStorage.setItem('djakjak.backend', 'wasm'); } catch (e) { /* ignore */ } }
      return backend;
    } catch (err) {
      console.warn('backend failed:', ep, err);
    }
  }
  throw new Error('تعذر تشغيل محرك الذكاء الاصطناعي على هذا الجهاز');
}

async function fallbackToWasm() {
  session = await create('wasm');
  backend = 'wasm';
  try { localStorage.setItem('djakjak.backend', 'wasm'); } catch (e) { /* ignore */ }
}

function drawToPixels(bitmap, maxSide) {
  const w = bitmap.width, h = bitmap.height;
  const s = Math.min(1, maxSide / Math.max(w, h));
  const iw = Math.max(1, Math.round(w * s));
  const ih = Math.max(1, Math.round(h * s));
  const c = document.createElement('canvas');
  c.width = iw; c.height = ih;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.imageSmoothingEnabled = true;
  g.imageSmoothingQuality = 'high';
  g.drawImage(bitmap, 0, 0, iw, ih);
  return { iw, ih, src: g.getImageData(0, 0, iw, ih).data };
}

/**
 * Enhance an image.
 * @param {ImageBitmap} bitmap decoded photo (EXIF orientation already applied)
 * @param {number} maxSide longest side of the working image in pixels
 * @param {{onProgress:(p:{done:number,total:number,avgMs:number})=>void, shouldCancel:()=>boolean}} hooks
 */
export async function enhance(bitmap, maxSide, hooks) {
  await loadEngine();
  const { iw, ih, src } = drawToPixels(bitmap, maxSide);
  const ow = iw * SCALE, oh = ih * SCALE;
  const out = new Uint8ClampedArray(ow * oh * 4);

  const cols = Math.ceil(iw / CORE), rows = Math.ceil(ih / CORE);
  const total = cols * rows;
  const plane = TILE * TILE;
  const OW = TILE * SCALE;
  const inp = new Float32Array(3 * plane);
  let done = 0, spent = 0;

  for (let ty = 0; ty < rows; ty++) {
    for (let tx = 0; tx < cols; tx++) {
      if (hooks.shouldCancel()) throw new Error('cancelled');
      const x0 = tx * CORE, y0 = ty * CORE;
      const cw = Math.min(CORE, iw - x0), ch = Math.min(CORE, ih - y0);

      for (let j = 0; j < TILE; j++) {
        const sy = reflect(y0 - PAD + j, ih);
        for (let i = 0; i < TILE; i++) {
          const sx = reflect(x0 - PAD + i, iw);
          const p = (sy * iw + sx) * 4;
          const o = j * TILE + i;
          inp[o] = src[p] / 255;
          inp[plane + o] = src[p + 1] / 255;
          inp[2 * plane + o] = src[p + 2] / 255;
        }
      }

      const t0 = performance.now();
      let res;
      try {
        res = await runTile(session, inp);
      } catch (err) {
        if (backend === 'webgl') { await fallbackToWasm(); res = await runTile(session, inp); }
        else throw err;
      }
      spent += performance.now() - t0;
      const y = res.output.data;
      const oplane = OW * OW;

      for (let j = 0; j < ch * SCALE; j++) {
        const oy = PAD * SCALE + j;
        const dy = y0 * SCALE + j;
        const brow = (PAD + (j >> 2)) * TILE + PAD;
        for (let i = 0; i < cw * SCALE; i++) {
          const yi = oy * OW + PAD * SCALE + i;
          const bi = brow + (i >> 2);
          const d = (dy * ow + x0 * SCALE + i) * 4;
          out[d] = (y[yi] + inp[bi]) * 255;
          out[d + 1] = (y[oplane + yi] + inp[plane + bi]) * 255;
          out[d + 2] = (y[2 * oplane + yi] + inp[2 * plane + bi]) * 255;
          out[d + 3] = 255;
        }
      }

      done++;
      hooks.onProgress({ done, total, avgMs: spent / done });
      await new Promise((r) => setTimeout(r, 0)); // let the UI breathe
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = ow; canvas.height = oh;
  canvas.getContext('2d').putImageData(new ImageData(out, ow, oh), 0, 0);
  const blob = await new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('encode failed'))), 'image/jpeg', 0.95));
  return { blob, width: ow, height: oh, backend };
}
