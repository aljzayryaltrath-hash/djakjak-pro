// Optional: regenerates the Android launcher icons from www/img/logo.svg.
// Usage: npm i --no-save sharp && node scripts/make-icons.cjs
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const svg = fs.readFileSync(path.join(__dirname, '../www/img/logo.svg'));
const out = path.join(__dirname, '../android-res');
const BG = '#0A3D2A';
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };

const emblem = (size) => sharp(svg, { density: 300 }).resize(size, size).png().toBuffer();

(async () => {
  for (const [d, k] of Object.entries(dens)) {
    const dir = path.join(out, `mipmap-${d}`);
    fs.mkdirSync(dir, { recursive: true });
    const legacy = Math.round(48 * k), fg = Math.round(108 * k);
    // legacy square icon (rounded square, emblem fills 86%)
    const inner = await emblem(Math.round(legacy * 0.86));
    const r = Math.round(legacy * 0.22);
    const mask = Buffer.from(`<svg width="${legacy}" height="${legacy}"><rect width="${legacy}" height="${legacy}" rx="${r}" fill="#fff"/></svg>`);
    const square = await sharp({ create: { width: legacy, height: legacy, channels: 4, background: BG } })
      .composite([{ input: inner, gravity: 'center' }, { input: mask, blend: 'dest-in' }]).png().toBuffer();
    fs.writeFileSync(path.join(dir, 'ic_launcher.png'), square);
    // round icon
    const circ = Buffer.from(`<svg width="${legacy}" height="${legacy}"><circle cx="${legacy / 2}" cy="${legacy / 2}" r="${legacy / 2}" fill="#fff"/></svg>`);
    const round = await sharp({ create: { width: legacy, height: legacy, channels: 4, background: BG } })
      .composite([{ input: await emblem(Math.round(legacy * 0.9)), gravity: 'center' }, { input: circ, blend: 'dest-in' }]).png().toBuffer();
    fs.writeFileSync(path.join(dir, 'ic_launcher_round.png'), round);
    // adaptive foreground: emblem inside the 66% safe zone
    const emb = await emblem(Math.round(fg * 0.62));
    const fgImg = await sharp({ create: { width: fg, height: fg, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
      .composite([{ input: emb, gravity: 'center' }]).png().toBuffer();
    fs.writeFileSync(path.join(dir, 'ic_launcher_foreground.png'), fgImg);
  }
  const nodpi = path.join(out, 'drawable-nodpi');
  fs.mkdirSync(nodpi, { recursive: true });
  fs.writeFileSync(path.join(nodpi, 'splash_logo.png'), await emblem(420));
  fs.writeFileSync(path.join(__dirname, '../www/img/icon-192.png'), await emblem(192));
  fs.writeFileSync(path.join(__dirname, '../www/img/icon-512.png'), await emblem(512));
  console.log('icons done');
})();
