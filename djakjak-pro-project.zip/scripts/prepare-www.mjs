// Copies the ONNX Runtime Web files into www/ort so the app works fully offline.
import { cpSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'node_modules/onnxruntime-web/dist');
const dest = join(root, 'www/ort');
mkdirSync(dest, { recursive: true });
for (const f of ['ort.min.js', 'ort-wasm-simd-threaded.wasm', 'ort-wasm-simd-threaded.mjs']) {
  if (!existsSync(join(dist, f))) throw new Error('missing ' + f + ' - run npm install first');
  cpSync(join(dist, f), join(dest, f));
}
console.log('ort files copied to www/ort');
