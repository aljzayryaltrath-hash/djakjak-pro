// Run after `npx cap add android`. Applies the Djakjak Pro branding to the generated Android project:
// launcher icons, splash screen, portrait lock.
import { cpSync, existsSync, readFileSync, readdirSync, rmSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const res = join(root, 'android/app/src/main/res');
const manifest = join(root, 'android/app/src/main/AndroidManifest.xml');
if (!existsSync(res)) throw new Error('android/ not found - run "npx cap add android" first');

// 1) icons + splash logo
cpSync(join(root, 'android-res'), res, { recursive: true });

// 2) adaptive icon background colour
writeFileSync(join(res, 'values/ic_launcher_background.xml'),
  '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0A3D2A</color>\n</resources>\n');

// 3) splash: drop the stock Capacitor images, use a dark-green screen with our logo
for (const d of readdirSync(res)) {
  const p = join(res, d);
  if (statSync(p).isDirectory() && d.startsWith('drawable')) {
    const f = join(p, 'splash.png');
    if (existsSync(f)) rmSync(f);
  }
}
mkdirSync(join(res, 'drawable'), { recursive: true });
writeFileSync(join(res, 'drawable/splash.xml'),
`<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/ic_launcher_background"/>
    <item>
        <bitmap android:src="@drawable/splash_logo" android:gravity="center"/>
    </item>
</layer-list>
`);

// Android 12+ system splash background
const styles = join(res, 'values/styles.xml');
let st = readFileSync(styles, 'utf8');
if (!st.includes('windowSplashScreenBackground')) {
  st = st.replace('<item name="android:background">@drawable/splash</item>',
    '<item name="android:background">@drawable/splash</item>\n        <item name="windowSplashScreenBackground">@color/ic_launcher_background</item>');
  writeFileSync(styles, st);
}

// 4) lock to portrait
let m = readFileSync(manifest, 'utf8');
if (!m.includes('screenOrientation')) {
  m = m.replace('android:launchMode="singleTask"', 'android:launchMode="singleTask"\n            android:screenOrientation="portrait"');
  writeFileSync(manifest, m);
}
console.log('android project branded');
